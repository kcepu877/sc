from cybervpn import *
import sqlite3
import datetime as DT
import subprocess
import random
import re
import base64
import json
import time
from telethon import events

@bot.on(events.CallbackQuery(data=b'create-shadowsocks-member'))
async def create_shadowsocks(event):
    user_id = str(event.sender_id)

    async def create_shadowsocks_(event):
        try:
            async with bot.conversation(chat) as user_conv:
                await event.respond('**Username:**')
                user_msg = user_conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
                user = (await user_msg).raw_text

            async with bot.conversation(chat) as exp_conv:
                await event.respond("**Expired:**", buttons=[[Button.inline(" 30 Day ", "30")]])
                exp_msg = exp_conv.wait_event(events.CallbackQuery)
                exp = (await exp_msg).data.decode("ascii")

            await event.edit("Processing.")
            await event.edit("Processing..")
            await event.edit("Processing...")
            await event.edit("Processing....")
            time.sleep(1)
            await event.edit("`Processing Create Premium Account`")
            time.sleep(1)
            await event.edit("`Wait.. Setting up an Account`")

            # Assuming this function checks and processes user balance for SSH
            await process_user_balance_ssh(event, user_id)

            cmd = f'printf "%s\n" "{user}" "{exp}" | addss-bot'

            a = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT).decode("utf-8")

        except subprocess.CalledProcessError as e:
            print(f"Error executing command: {e}")
            print(f"Exit code: {e.returncode}")
            print(f"Output: {e.output.decode('utf-8')}")
            await event.respond(f"Error executing command: {e}")
            return  # Stop execution to prevent further processing on error

        except Exception as ex:
            print(f"Unexpected error: {ex}")
            await event.respond("An unexpected error occurred.")
            return  # Stop execution to prevent further processing on error

        today = DT.date.today()
        later = today + DT.timedelta(days=int(exp))
        x = [x.group() for x in re.finditer("ss://(.*)", a)]
        uuid = re.search("ss://(.*?)@", x[0]).group(1)

        msg = f"""
        
**◇━━━━━━━━━━━━━━━━━◇**
**⟨🔸SHDWSCSK Account🔸⟩**
**◇━━━━━━━━━━━━━━━━━◇**
**» Remarks :** `{user}`
**» Host Server :** `{DOMAIN}`
**» Port TLS    :** `443`
**» Port NTLS   :** `80`
**» UUID    :** `{uuid}`
**» NetWork     :** `(WS) or (gRPC)`
**» Path        :** `/ss-ws`
**» ServiceName :** `ss-grpc`
**◇━━━━━━━━━━━━━━━━━◇**
**» URL TLS    :**
```{x[0]}```
**◇━━━━━━━━━━━━━━━━━◇**
**» URL HTTP   :** 
```{x[1].replace(" ","")}```
**◇━━━━━━━━━━━━━━━━━◇**
**» URL gRPC   :** 
```{x[2].replace(" ","")}```
**◇━━━━━━━━━━━━━━━━━◇**
**⟨Link Save Account⟩**
https://{DOMAIN}:81/ss-{user}.txt
**◇━━━━━━━━━━━━━━━━━◇**
**» Expired Until:** `{later}`
**◇━━━━━━━━━━━━━━━━━◇**
»  

        """

        await event.respond(msg)

    chat = event.chat_id
    sender = await event.get_sender()

    try:
        level = get_level_from_db(user_id)
        print(f'Retrieved level from database: {level}')

        if level == 'user':
            await create_shadowsocks_(event)
        else:
            await event.answer(f'Akses Ditolak.!!', alert=True)

    except Exception as e:
        print(f'Error: {e}')









@bot.on(events.CallbackQuery(data=b'cek-shadowsocks-member'))
async def cek_shadowsocks(event):
    user_id = str(event.sender_id)
    async def cek_shadowsocks_(event):
        cmd = 'bash cek-mss'.strip()
        x = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
        print(x)
        z = subprocess.check_output(cmd, shell=True).decode("utf-8")
        await event.respond(f"""
        
        {z}

**Shows Users Shadowsocks in database**
        """, buttons=[[Button.inline("‹ 𝙼𝚊𝚒𝚗 𝙼𝚎𝚗𝚞 ›", "menu")]])

    chat = event.chat_id
    sender = await event.get_sender()

    try:
        level = get_level_from_db(user_id)
        print(f'Retrieved level from database: {level}')

        if level == 'user':
            await cek_shadowsocks_(event)
        else:
            await event.answer('Akses Ditolak.!!', alert=True)

    except Exception as e:
        print(f'Error: {e}')




@bot.on(events.CallbackQuery(data=b'cek-shadowsocks-online-member'))
async def cek_shadowsocks(event):
    user_id = str(event.sender_id)
    async def cek_shadowsocks_(event):
        cmd = 'bash cek-ss'.strip()
        x = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
        print(x)
        z = subprocess.check_output(cmd, shell=True).decode("utf-8")
        await event.respond(f"""
**◇━━━━━━━━━━━━━━━━━━◇**
 ** ⟨🔸Shdwsk Login Account🔸⟩**
**◇━━━━━━━━━━━━━━━━━━◇**
{z}

**Shows Users shadowsocks Login**
        """, buttons=[[Button.inline("‹ 𝙼𝚊𝚒𝚗 𝙼𝚎𝚗𝚞 ›", "menu")]])

    chat = event.chat_id
    sender = await event.get_sender()

    try:
        level = get_level_from_db(user_id)
        print(f'Retrieved level from database: {level}')

        if level == 'user':
            await cek_shadowsocks_(event)
        else:
            await event.answer('Akses Ditolak.!!', alert=True)

    except Exception as e:
        print(f'Error: {e}')



















@bot.on(events.CallbackQuery(data=b'delete-shadowsocks'))
async def delete_shadowsocks(event):
    async def delete_shadowsocks_(event):
        async with bot.conversation(chat) as user_conv:
            await event.respond('**Username:**')
            user_event = user_conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            user_text = (await user_event).raw_text

        cmd = f'printf "%s\n" "{user_text}" | bot-del-ss'
        try:
            output = subprocess.check_output(cmd, shell=True).decode("utf-8")
        except subprocess.CalledProcessError:
            await event.respond("**Successfully Renew Or Delete User**")
        else:
            msg = "**Successfully Deleted**"
            await event.respond(msg)

    chat = event.chat_id
    sender = await event.get_sender()

    try:
        level = get_level_from_db(sender.id)
        print(f'Retrieved level from database: {level}')

        if level == 'admin':
            await delete_shadowsocks_(event)
        else:
            await event.answer('Akses Ditolak.!!', alert=True)

    except Exception as e:
        print(f'Error: {e}')







@bot.on(events.CallbackQuery(data=b'trial-shadowsocks-member'))
async def trial_shadowsocks(event):
    user_id = str(event.sender_id)
    pw = "1"
    exp = "1"
    ip = "1"

    # Database connection
    conn = sqlite3.connect('users.db')
    cursor = conn.cursor()

    # Create table if it doesn't exist
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS users (
            user_id TEXT PRIMARY KEY,
            has_trial INTEGER DEFAULT 0,
            last_trial_date TEXT
        )
    ''')
    conn.commit()

    # Function to check if user can trial again today
    async def can_user_trial_again(user_id):
        cursor.execute('SELECT last_trial_date FROM users WHERE user_id = ?', (user_id,))
        result = cursor.fetchone()
        today = DT.date.today().isoformat()

        if result is None:
            # If user does not exist in the database, add them
            cursor.execute('INSERT INTO users (user_id, has_trial, last_trial_date) VALUES (?, ?, ?)', (user_id, 0, None))
            conn.commit()
            return True  # User has never trialed, allow trial

        last_trial_date = result[0]

        if last_trial_date is None or last_trial_date != today:
            # If user hasn't trialed today, allow trial
            return True

        # User has already trialed today
        return False

    # Function to mark today's trial date
    async def mark_user_trial_today(user_id):
        today = DT.date.today().isoformat()
        cursor.execute('UPDATE users SET last_trial_date = ? WHERE user_id = ?', (today, user_id))
        conn.commit()

    async def trial_shadowsocks_(event):
        # Loading animation
        for dots in range(1, 5):
            await event.edit(f"Processing{'.' * dots}")
            await asyncio.sleep(0.5)

        await event.edit("`Processing Create Premium Account`")
        await asyncio.sleep(1)

        # Output command (ensure exp and DOMAIN are defined elsewhere)
        cmd = f'printf "%s\n" "Trial$(</dev/urandom tr -dc X-Z0-9 | head -c4)" "1" "1" "1" | bot-trialss'

        try:
            # Capture output safely
            a = subprocess.check_output(cmd, shell=True, text=True).strip()
        except subprocess.CalledProcessError as e:
            print(f'Error: {e}')
            await event.respond(f"An error occurred: {e}")
            return  # Stop execution if there's an error

        today = DT.date.today()
        later = today + DT.timedelta(days=int(exp))  # Ensure 'exp' is defined

        # Extract ss links using regex
        b = [x.group() for x in re.finditer(r"ss://(.*)", a)]
        if not b or len(b) < 3:
            await event.respond("Error: Could not generate ss links correctly.")
            return

        # Parsing values from the ss links
        domain = re.search(r"@(.*?):", b[0]).group(1)
        uuid = re.search(r"ss://(.*?)@", b[0]).group(1)

        # Constructing the message to send
        msg = f"""
**◇━━━━━━━━━━━━━━━━━◇**
    **⟨🔸Trial Shadowsocks 🔸⟩**
**◇━━━━━━━━━━━━━━━━━◇**
**» Port TLS    :** `443`
**» Port NTLS   :** `80`
**» UUID        :** `{uuid}`
**» NetWork     :** `(WS) or (gRPC)`
**» Path        :** `/ss-ws or /ss-grpc`
**» Expired Until:** `{later}`
**◇━━━━━━━━━━━━━━━━━◇**
**» URL TLS    :**
```{b[0]}```
**◇━━━━━━━━━━━━━━━━━◇**
**» URL HTTP    :**
```{b[1].replace(" ", "")}```
**◇━━━━━━━━━━━━━━━━━◇**
**» URL gRPC   :** 
```{b[2].replace(" ", "")}```
**◇━━━━━━━━━━━━━━━━━◇**
**» ** 🤖@Lite_Vermilion
        """
        await event.respond(msg)
        
        def split_message(message, chunk_size=4096):
            return [message[i:i+chunk_size] for i in range(0, len(message), chunk_size)]

        # Memisahkan pesan panjang
        messages = split_message(msg)

        # Kirim setiap bagian pesan
        for message in messages:
            await bot.send_message(event.chat_id, message)

    chat = event.chat_id
    sender = await event.get_sender()

    try:
        if await can_user_trial_again(user_id):
            await trial_shadowsocks_(event)
            await mark_user_trial_today(user_id)  # Mark the trial as used for today
        else:
            await event.answer("Anda sudah menggunakan trial hari ini.", alert=True)
    except Exception as e:
        print(f'Error: {e}')
        await event.respond(f"An error occurred: {e}")
    finally:
        # Close the database connection after the function is done
        conn.close()





@bot.on(events.CallbackQuery(data=b'renew-ss-member'))
async def ren_ss(event):
    async def ren_ss_(event):
        async with bot.conversation(chat) as user_conv:
            await event.respond('**Username:**')
            user = await user_conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            user = user.raw_text

            
        await process_user_balance_ssh(event, user_id)
        cmd = f'printf "%s\n" "{user}" "30" | bot-renew-ss'

        try:
            a = subprocess.check_output(cmd, shell=True).decode("utf-8")
        except:
            await event.respond("**Successfully Renew Or Delete User**")
        else:
            msg = f"""**Successfully Renewed  {user} 30 Days**"""
            await event.respond(msg)

    user_id = str(event.sender_id)
    chat = event.chat_id
    sender = await event.get_sender()

    try:
        level = get_level_from_db(user_id)
        print(f'Retrieved level from database: {level}')

        if level == 'user':
            await ren_ss_(event)
        else:
            await event.answer(f'Akses Ditolak. Level: {level}', alert=True)
    except Exception as e:
        print(f'Error: {e}')




@bot.on(events.CallbackQuery(data=b'shadowsocks-member'))
async def shadowsocks(event):
    user_id = str(event.sender_id)

    async def shadowsocks_(event):
        inline = [
            [Button.inline("𝚃𝚛𝚒𝚊𝚕 𝚂𝚑𝚍𝚠𝚜𝚔", "trial-shadowsocks-member"),
             Button.inline("𝙲𝚛𝚎𝚊𝚝𝚎 𝚂𝚑𝚍𝚠𝚜𝚔", "create-shadowsocks-member")],
            [Button.inline("𝙲𝚑𝚎𝚌𝚔 𝙾𝚗𝚕𝚒𝚗𝚎 𝚄𝚜𝚎𝚛", "cek-shadowsocks-online-member"),
             Button.inline("𝙲𝚑𝚎𝚌𝚔 𝙼𝚎𝚖𝚋𝚎𝚛", "cek-shadowsocks-member")],
            [Button.inline("𝚁𝚎𝚗𝚎𝚠 𝚂𝚑𝚍𝚠𝚜𝚔", "renew-ss-member")],
            [Button.inline("‹ 𝙼𝚊𝚒𝚗 𝙼𝚎𝚗𝚞 ›", "menu")]]
        
        z = requests.get(f"http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
        msg = f"""
**◇━━━━━━━━━━━━━━━━━◇**
 **◇⟨🔸SHDWSK SERVICE🔸⟩◇**
**◇━━━━━━━━━━━━━━━━━◇**
» Service: `SHADOWSOCKS`
» Hostname/IP: `{DOMAIN}`
» ISP: `{z["isp"]}`
» Country: `{z["country"]}`
**» ** 
**◇━━━━━━━━━━━━━━━━━◇**
"""

        await event.edit(msg, buttons=inline)

    chat = event.chat_id
    sender = await event.get_sender()

    try:
        level = get_level_from_db(user_id)
        print(f'Retrieved level from database: {level}')

        if level == 'user':
            await shadowsocks_(event)
        else:
            await event.answer(f'Akses Ditolak.!!', alert=True)
    except Exception as e:
        print(f'Error: {e}')


