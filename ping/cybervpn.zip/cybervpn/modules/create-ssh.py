from cybervpn import *
import subprocess
import datetime as DT
import sys
from telethon.sync import TelegramClient
import sqlite3

@bot.on(events.CallbackQuery(data=b'create-ssh'))
async def create_ssh(event):
    chat = event.chat_id
    sender = await event.get_sender()
    
    async with bot.conversation(chat) as conv:
        # Asking for the necessary details including price
        await event.respond('**Username:**')
        user = (await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))).raw_text

        await event.respond("**Password:**")
        pw = (await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))).raw_text

        await event.respond("**Expired day:**")
        exp = (await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))).raw_text

        # Asking for the login IP
        await event.respond("**Login IP:**")
        login_ip = (await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))).raw_text
        await event.edit("`Wait.. Setting up an Account`")
        
        # Create SSH user
        cmd = f'useradd -e `date -d "{exp} days" +"%Y-%m-%d"` -s /bin/false -M {user} && echo "{pw}\n{pw}" | passwd {user}'
        try:
            subprocess.check_output(cmd, shell=True)
        except subprocess.CalledProcessError:
            await event.respond("**User Sudah ada**")
            return

        # Apply IP restriction (example: using iptables or modifying sshd_config)
        ip_cmd = f"iptables -A INPUT -p tcp --dport 22 -s {login_ip} -j ACCEPT"
        try:
            subprocess.check_output(ip_cmd, shell=True)
        except subprocess.CalledProcessError:
            await event.respond(f"**Failed to apply IP restriction for {login_ip}**")
            return

        # Calculate expiry date
        today = DT.date.today()
        later = today + DT.timedelta(days=int(exp))

        # Message with account details including the price
        msg = f"""
**═════════════════════════**
            **❞CREATE SSH WS❞**
**═════════════════════════**
**❞Host:**  `{DOMAIN}`
**❞Username:**  `{user}`
**❞Password:**  `{pw}`
**═════════════════════════**
**❞UDP CUSTOM:**
`{DOMAIN}:1-65535@{user}:{pw}`
**═════════════════════════**
**❞SSH CUSTOM:**
`{DOMAIN}:80@{user}:{pw}`
**═════════════════════════**
**❞Payload WebSocket⟩**
```GET /cdn-cgi/trace HTTP/1.1[crlf]Host: Bug_Kalian[crlf][crlf]GET-RAY / HTTP/1.1[crlf]Host: [host][crlf]Connection: Upgrade[crlf]User-Agent: [ua][crlf]Upgrade: websocket[crlf][crlf]```
**═════════════════════════**
**❞Expired on:** `{later}`
**═════════════════════════**
**☞ó ‌つò☞ **
**═════════════════════════**
"""

        # Inline buttons for Telegram and WhatsApp links
         chat = event.chat_id
    sender = await event.get_sender()

    try:
        # Check user level from the database
        level = get_level_from_db(sender.id)
        print(f'Retrieved level from database: {level}')

        if level == 'admin':
            await create_ssh_(event)
        else:
            await event.answer(f'Akses Ditolak..!!', alert=True)
    except Exception as e:
        print(f'Error: {e}')